
export interface NewsItem {
  id: string;
  title: string;
  date: string;
  snippet: string;
  content: string;
}

export interface HomeData {
  heroTitle: string;
  heroSubtitle: string;
  heroImage: string;
  welcomeTitle: string;
  welcomeText: string;
  newsTitle: string;
  newsItems: NewsItem[];
}

export interface Official {
  id: string;
  name: string;
  role: string;
  description: string;
  imageUrl: string;
  extraInfo?: string;
}

export interface OfficialsData {
  pageTitle: string;
  pageSubtitle: string;
  cabinetTitle: string;
  governor: Official;
  cabinet: Official[];
}

export interface CongressMember {
  id: string;
  name: string;
  party: string;
  district: string;
  imageUrl: string;
}

export interface CongressData {
  pageTitle: string;
  pageSubtitle: string;
  members: CongressMember[];
}

export interface LawItem {
  id: string;
  title: string;
  description: string;
  link: string;
}

export interface LawsData {
  pageTitle: string;
  pageSubtitle: string;
  items: LawItem[];
}

export interface BusinessEntry {
  id: string;
  name: string;
  type: string;
  owner: string;
  status: "Active" | "Suspended" | string;
  registeredDate: string;
  expiryDate: string;
}

export interface BusinessData {
  pageTitle: string;
  pageSubtitle: string;
  registry: BusinessEntry[];
}

export interface ServiceItem {
  id: string;
  title: string;
  description: string;
  icon: string; // Name of the icon
  linkText: string;
}

export interface ServicesData {
  pageTitle: string;
  pageSubtitle: string;
  items: ServiceItem[];
}

export interface ArchiveData {
  pageTitle: string;
  pageSubtitle: string;
}

export interface FooterData {
  title: string;
  copyrightText: string;
}

export interface AppData {
  home: HomeData;
  officials: OfficialsData;
  congress: CongressData;
  laws: LawsData;
  business: BusinessData;
  services: ServicesData;
  archive: ArchiveData;
  footer: FooterData;
}
