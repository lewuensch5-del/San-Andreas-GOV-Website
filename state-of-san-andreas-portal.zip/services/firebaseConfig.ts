
import { initializeApp } from "firebase/app";
import { getFirestore } from "firebase/firestore";

const firebaseConfig = {
  apiKey: "AIzaSyDhqm_Vtj2cH7uREFSQbVdIYdNdsD52rAw",
  authDomain: "website-state-of-san-andreas.firebaseapp.com",
  projectId: "website-state-of-san-andreas",
  storageBucket: "website-state-of-san-andreas.firebasestorage.app",
  messagingSenderId: "916267194208",
  appId: "1:916267194208:web:8ba0377c0d9b747936b005",
  measurementId: "G-QDVKGFVWQ8"
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);
// Analytics removed to prevent "Component analytics has not been registered yet" error
// const analytics = getAnalytics(app); 
const db = getFirestore(app);

// Flag to check connection in other components
const isDbConnected = true;

export { db, isDbConnected };
