
// Supabase Integration deaktiviert
export const supabase = null;
export const isDbConnected = false;
