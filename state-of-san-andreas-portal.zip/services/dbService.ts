
import { collection, doc, writeBatch, onSnapshot } from "firebase/firestore";
import { db } from './firebaseConfig';
import { AppData } from '../types';
import { APP_DATA as DEFAULT_DATA } from '../constants';

const COLLECTION_NAME = "settings";
const LOCAL_STORAGE_KEY = "app_data_fallback";

// The sections of AppData that will be stored as individual documents
const SECTIONS = [
  'home', 
  'officials', 
  'congress', 
  'laws', 
  'business', 
  'services', 
  'archive', 
  'footer'
];

export const dbService = {
  /**
   * Subscribes to realtime updates from the Firestore collection.
   * Merges multiple documents (shards) into a single AppData object.
   */
  subscribeToData(onDataUpdate: (data: AppData) => void, onError?: (code: string) => void) {
    // 1. Try to load local data immediately for instant render
    const local = localStorage.getItem(LOCAL_STORAGE_KEY);
    if (local) {
      try {
        console.log("Lade Daten aus lokalem Speicher...");
        onDataUpdate(JSON.parse(local));
      } catch (e) {
        console.error("Fehler beim Laden aus LocalStorage:", e);
        onDataUpdate(DEFAULT_DATA);
      }
    } else {
      onDataUpdate(DEFAULT_DATA);
    }

    if (!db) {
      console.error("Firebase DB not initialized");
      return () => {};
    }

    const colRef = collection(db, COLLECTION_NAME);

    // 2. Listen for changes in the entire 'settings' collection
    const unsubscribe = onSnapshot(colRef, (snapshot) => {
      // Start with default data structure
      let constructedData: any = { ...DEFAULT_DATA };

      // First, check for legacy single-document data to ensure backward compatibility
      const legacyDoc = snapshot.docs.find(d => d.id === 'site_content');
      if (legacyDoc && legacyDoc.exists()) {
         constructedData = { ...constructedData, ...legacyDoc.data() };
      }

      // Then, overwrite with any new split-document data found
      snapshot.docs.forEach(docSnap => {
         if (SECTIONS.includes(docSnap.id)) {
            constructedData[docSnap.id] = docSnap.data();
         }
      });

      console.log("Update vom Server empfangen (Split-Mode)");
      
      // Update local cache
      localStorage.setItem(LOCAL_STORAGE_KEY, JSON.stringify(constructedData));
      onDataUpdate(constructedData as AppData);

    }, (error) => {
      // Handle Permission Denied silently to allow "Offline Mode"
      if (error.code === 'permission-denied') {
          console.warn("Firestore permission denied. App operating in Local/Offline Mode.");
          return;
      }
      
      console.error("Firestore Listener Error:", error);
      if (onError) onError(error.code);
    });

    return unsubscribe;
  },

  /**
   * Saves data by splitting AppData into multiple documents using a Batch Write.
   */
  async saveData(data: AppData): Promise<void> {
    // Always save locally first
    try {
        localStorage.setItem(LOCAL_STORAGE_KEY, JSON.stringify(data));
    } catch (e) {
        console.error("LocalStorage write failed", e);
    }

    if (!db) return;
    
    try {
      const batch = writeBatch(db);

      // Loop through each section and schedule it for saving in its own document
      SECTIONS.forEach(sectionKey => {
         const docRef = doc(db, COLLECTION_NAME, sectionKey);
         // @ts-ignore - accessing data dynamically
         const sectionData = data[sectionKey];
         
         if (sectionData) {
             batch.set(docRef, sectionData);
         }
      });

      // Commit all changes atomically
      await batch.commit();
      console.log("Daten erfolgreich (gesplittet) gespeichert");

    } catch (error: any) {
      if (error.code === 'permission-denied') {
        console.warn("Cloud-Speichern abgelehnt (Permission Denied). Nur lokal gespeichert.");
        return; 
      }
      console.error("Fehler beim Speichern:", error);
      throw error;
    }
  }
};
