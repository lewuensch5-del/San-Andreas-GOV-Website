import { GoogleGenAI, GenerateContentResponse } from "@google/genai";

const apiKey = process.env.API_KEY || "";

// Initialize the Gemini Client only if the key is available to prevent errors on start
const ai = apiKey ? new GoogleGenAI({ apiKey }) : null;

export const getChatResponse = async (
  message: string,
  contextData: string
): Promise<string> => {
  if (!ai) {
    return "System: API Key missing. Please configure the environment.";
  }

  try {
    const model = ai.models;
    const prompt = `
      You are the AI Assistant for the State of San Andreas Government Portal.
      You are helpful, formal, and knowledgeable about the provided state data.
      
      Here is the context of the website data:
      ${contextData}

      User Question: ${message}
      
      Answer concisely and professionally.
    `;

    const response: GenerateContentResponse = await model.generateContent({
      model: "gemini-2.5-flash",
      contents: prompt,
    });

    return response.text || "I apologize, I could not generate a response at this time.";
  } catch (error) {
    console.error("Error querying Gemini:", error);
    return "An error occurred while contacting the government servers.";
  }
};
