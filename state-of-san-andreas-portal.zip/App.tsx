
import React from 'react';
import { HashRouter as Router, Routes, Route } from 'react-router-dom';
import Navbar from './components/Navbar';
import Footer from './components/Footer';
import Home from './pages/Home';
import Officials from './pages/Officials';
import Congress from './pages/Congress';
import Laws from './pages/Laws';
import Business from './pages/Business';
import Admin from './pages/Admin';
import NewsDetail from './pages/NewsDetail';
import Services from './pages/Services';
import Archive from './pages/Archive';
import AIChat from './components/AIChat';
import { DataProvider } from './context/DataContext';
import { ThemeProvider } from './context/ThemeContext';

function AppContent() {
  return (
    <Router>
      <div className="flex flex-col min-h-screen bg-slate-50 dark:bg-slate-950 font-sans text-slate-900 dark:text-slate-100 transition-colors duration-300">
        <Navbar />
        <main className="flex-grow">
          <Routes>
            <Route path="/" element={<Home />} />
            <Route path="/news/:id" element={<NewsDetail />} />
            <Route path="/officials" element={<Officials />} />
            <Route path="/congress" element={<Congress />} />
            <Route path="/laws" element={<Laws />} />
            <Route path="/business" element={<Business />} />
            <Route path="/services" element={<Services />} />
            <Route path="/archive" element={<Archive />} />
            <Route path="/admin" element={<Admin />} />
          </Routes>
        </main>
        
        {/* Dynamic Footer */}
        <Footer />

        {/* AI Chat Widget */}
        <AIChat />
      </div>
    </Router>
  );
}

function App() {
  return (
    <DataProvider>
      <ThemeProvider>
        <AppContent />
      </ThemeProvider>
    </DataProvider>
  );
}

export default App;
