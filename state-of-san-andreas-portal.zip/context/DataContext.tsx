
import React, { createContext, useState, useContext, useEffect, ReactNode } from 'react';
import { AppData, HomeData, OfficialsData, CongressData, LawsData, BusinessData, NewsItem, FooterData, ServicesData, ArchiveData } from '../types';
import { APP_DATA as DEFAULT_DATA } from '../constants';
import { dbService } from '../services/dbService';

interface DataContextType {
  data: AppData;
  isLoading: boolean;
  error: string | null;
  updateHome: (data: HomeData) => Promise<void>;
  updateOfficials: (data: OfficialsData) => Promise<void>;
  updateCongress: (data: CongressData) => Promise<void>;
  updateLaws: (data: LawsData) => Promise<void>;
  updateBusiness: (data: BusinessData) => Promise<void>;
  updateServices: (data: ServicesData) => Promise<void>;
  updateArchive: (data: ArchiveData) => Promise<void>;
  updateFooter: (data: FooterData) => Promise<void>;
  updateHomeAndFooter: (home: HomeData, footer: FooterData) => Promise<void>; // New combined function
  addNewsItem: (item: NewsItem) => Promise<void>;
  deleteNewsItem: (id: string) => Promise<void>;
  resetData: () => Promise<void>;
  refreshData: () => void;
}

const DataContext = createContext<DataContextType | undefined>(undefined);

export const useData = () => {
  const context = useContext(DataContext);
  if (!context) {
    throw new Error('useData must be used within a DataProvider');
  }
  return context;
};

export const DataProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [data, setData] = useState<AppData>(DEFAULT_DATA);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  // Subscribe to Realtime Database on Mount
  useEffect(() => {
    setIsLoading(true);
    
    // Connect to Firestore and listen for changes
    const unsubscribe = dbService.subscribeToData(
      (newData) => {
        console.log("DataContext: Neue Daten empfangen (Init/Sync).");
        setData(newData);
        setIsLoading(false);
        setError(null);
      },
      (errCode) => {
        console.error("DataContext Error Code:", errCode);
        setError(errCode);
        setIsLoading(false);
      }
    );

    // Cleanup listener on unmount
    return () => {
      if (unsubscribe) unsubscribe();
    };
  }, []);

  // Helper to save to DB
  const save = async (newData: AppData) => {
    try {
      // 1. Update Local State IMMEDIATELY (Optimistic UI Update)
      setData(newData);

      // 2. Persist to DB / LocalStorage
      await dbService.saveData(newData);
    } catch (err: any) {
      console.error("Sync error:", err);
      throw new Error(err.message || "Fehler beim Speichern");
    }
  };

  const updateHome = async (homeData: HomeData) => {
    await save({ ...data, home: homeData });
  };

  const updateOfficials = async (officialsData: OfficialsData) => {
    await save({ ...data, officials: officialsData });
  };

  const updateCongress = async (congressData: CongressData) => {
    await save({ ...data, congress: congressData });
  };

  const updateLaws = async (lawsData: LawsData) => {
    await save({ ...data, laws: lawsData });
  };

  const updateBusiness = async (businessData: BusinessData) => {
    await save({ ...data, business: businessData });
  };

  const updateServices = async (servicesData: ServicesData) => {
    await save({ ...data, services: servicesData });
  };

  const updateArchive = async (archiveData: ArchiveData) => {
    await save({ ...data, archive: archiveData });
  };

  const updateFooter = async (footerData: FooterData) => {
    await save({ ...data, footer: footerData });
  };

  // NEW: Combined update to prevent race conditions
  const updateHomeAndFooter = async (homeData: HomeData, footerData: FooterData) => {
    await save({ ...data, home: homeData, footer: footerData });
  };

  const addNewsItem = async (item: NewsItem) => {
    const newData = {
      ...data,
      home: {
        ...data.home,
        newsItems: [item, ...data.home.newsItems]
      }
    };
    await save(newData);
  };

  const deleteNewsItem = async (id: string) => {
    const newData = {
      ...data,
      home: {
        ...data.home,
        newsItems: data.home.newsItems.filter(i => i.id !== id)
      }
    };
    await save(newData);
  };

  const resetData = async () => {
    if(window.confirm("Sind Sie sicher? Dies setzt die Datenbank für ALLE Nutzer auf den Standard zurück.")) {
        await save(DEFAULT_DATA);
        window.location.reload();
    }
  };

  const refreshData = () => {
    window.location.reload();
  };

  return (
    <DataContext.Provider value={{ 
      data, 
      isLoading,
      error,
      updateHome, 
      updateOfficials, 
      updateCongress, 
      updateLaws, 
      updateBusiness,
      updateServices,
      updateArchive,
      updateFooter,
      updateHomeAndFooter,
      addNewsItem,
      deleteNewsItem,
      resetData,
      refreshData
    }}>
      {children}
    </DataContext.Provider>
  );
};
