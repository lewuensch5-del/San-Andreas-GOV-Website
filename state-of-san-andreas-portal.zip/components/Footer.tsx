
import React from 'react';
import { useData } from '../context/DataContext';

const Footer: React.FC = () => {
  const { data } = useData();
  const { footer } = data;

  return (
    <footer className="bg-slate-900 dark:bg-black text-slate-400 py-8 border-t border-slate-800 transition-colors duration-300">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex flex-col md:flex-row justify-between items-center">
        <div className="mb-4 md:mb-0 text-center md:text-left">
          <span className="font-bold text-slate-100 text-lg block">{footer.title}</span>
          <p className="text-sm mt-1">{footer.copyrightText}</p>
        </div>
        <div className="flex space-x-6 text-sm">
          <a href="#" className="hover:text-white transition-colors">Impressum</a>
          <a href="#" className="hover:text-white transition-colors">Datenschutz</a>
          <a href="#" className="hover:text-white transition-colors">Kontakt</a>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
