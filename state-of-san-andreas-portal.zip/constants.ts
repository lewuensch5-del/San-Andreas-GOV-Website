
import { AppData } from './types';

export const APP_DATA: AppData = {
  "footer": {
    "title": "State of San Andreas",
    "copyrightText": "2025 Government of San Andreas. Website State of San Andreas. Alle Rechte vorbehalten."
  },
  "archive": {
    "pageTitle": "Nachrichtenarchiv",
    "pageSubtitle": "Alle offiziellen Pressemitteilungen und Bekanntmachungen."
  },
  "services": {
    "pageTitle": "Bürgerservice",
    "pageSubtitle": "Digitale Dienstleistungen für die Bürger von San Andreas.",
    "items": [
      {
        "id": "s1",
        "title": "Personalausweis & Pässe",
        "description": "Beantragung, Verlängerung und Verlustmeldung von Identifikationsdokumenten.",
        "icon": "IdCard",
        "linkText": "Termin vereinbaren"
      },
      {
        "id": "s2",
        "title": "Fahrzeugzulassung",
        "description": "An- und Ummeldung von Kraftfahrzeugen sowie Kennzeichenvergabe.",
        "icon": "Car",
        "linkText": "Zum DMV Portal"
      },
      {
        "id": "s3",
        "title": "Waffenschein",
        "description": "Anträge für den Besitz und das Führen von Schusswaffen (CCW).",
        "icon": "ShieldCheck",
        "linkText": "Informationen"
      },
      {
        "id": "s4",
        "title": "Heiratsurkunde",
        "description": "Registrierung von Eheschließungen und Ausstellung von Urkunden.",
        "icon": "HeartHandshake",
        "linkText": "Antrag stellen"
      }
    ]
  },
  "business": {
    "pageSubtitle": "Öffentliches Verzeichnis aller lizenzierten Unternehmen.",
    "pageTitle": "Gewerberegister",
    "registry": [
      {
        "expiryDate": "01.01.2026",
        "id": "b1",
        "name": "Vanilla Unicorn",
        "owner": "H. Simpson",
        "registeredDate": "01.01.2023",
        "status": "Active",
        "type": "Unterhaltung"
      },
      {
        "expiryDate": "15.03.2026",
        "id": "b2",
        "name": "Los Santos Customs",
        "owner": "F. Clinton",
        "registeredDate": "15.03.2023",
        "status": "Active",
        "type": "KFZ-Service"
      },
      {
        "expiryDate": "10.02.2023",
        "id": "b3",
        "name": "Yellow Jack Inn",
        "owner": "Unbekannt",
        "registeredDate": "10.02.2020",
        "status": "Suspended",
        "type": "Gastronomie"
      },
      {
        "expiryDate": "Unbefristet",
        "id": "b4",
        "name": "Fleeca Bank",
        "owner": "Holding Corp",
        "registeredDate": "01.05.2022",
        "status": "Active",
        "type": "Finanzen"
      }
    ]
  },
  "congress": {
    "members": [
      {
        "district": "Los Santos South",
        "id": "c1",
        "imageUrl": "https://picsum.photos/id/1062/300/300",
        "name": "John Doe",
        "party": "Demokraten"
      },
      {
        "district": "Paleto Bay",
        "id": "c2",
        "imageUrl": "https://picsum.photos/id/1011/300/300",
        "name": "Jane Smith",
        "party": "Republikaner"
      },
      {
        "district": "Sandy Shores",
        "id": "c3",
        "imageUrl": "https://picsum.photos/id/1005/300/300",
        "name": "Trevor Phillips",
        "party": "Unabhängig"
      },
      {
        "district": "Vinewood",
        "id": "c4",
        "imageUrl": "https://picsum.photos/id/1025/300/300",
        "name": "Michael De Santa",
        "party": "Demokraten"
      }
    ],
    "pageSubtitle": "Die legislative Kraft von San Andreas.",
    "pageTitle": "Der Kongress"
  },
  "home": {
    "heroImage": "https://picsum.photos/id/122/1920/600",
    "heroSubtitle": "Dienen. Schützen. Repräsentieren.",
    "heroTitle": "State of San Andreas",
    "welcomeTitle": "Willkommen im State of San Andreas",
    "welcomeText": "Das offizielle Portal der Regierung. Hier finden Sie aktuelle Nachrichten, Informationen zu Amtsträgern, Gesetze und das Gewerberegister.",
    "newsTitle": "Aktuelle Nachrichten",
    "newsItems": [
      {
        "content": "Der Kongress von San Andreas hat in seiner heutigen Sitzung den Haushaltsplan für das kommende Fiskaljahr verabschiedet. Schwerpunkte liegen auf dem Ausbau der Highway-Infrastruktur rund um Los Santos und der Förderung von öffentlichen Einrichtungen in Blaine County. Kritiker bemängeln jedoch die Kürzungen im Bereich der Forstverwaltung.",
        "date": "12.05.2024",
        "id": "1",
        "snippet": "Der Kongress hat heute einstimmig den neuen Infrastrukturplan bestätigt.",
        "title": "Haushaltsplan 2025 verabschiedet"
      },
      {
        "content": "In einer feierlichen Zeremonie vor dem Rathaus wurde heute Chief Miller als neuer Leiter des Los Santos Police Departments vereidigt. Gouverneur Washington lobte Millers langjährige Verdienste und betonte die Wichtigkeit einer bürgernahen Polizei.",
        "date": "10.05.2024",
        "id": "2",
        "snippet": "Führungswechsel beim LSPD: Neuer Chief vereidigt.",
        "title": "Neuer Polizeichef im Amt"
      }
    ]
  },
  "laws": {
    "pageTitle": "Gesetzbuch",
    "pageSubtitle": "Die rechtliche Grundlage unseres Staates.",
    "items": [
       {
         "id": "l1",
         "title": "Verfassung von San Andreas",
         "description": "Das Grundgesetz, das die Rechte der Bürger und die Struktur der Regierung regelt.",
         "link": "#"
       },
       {
         "id": "l2",
         "title": "Strafgesetzbuch (StGB)",
         "description": "Regelungen zu Straftaten und deren Ahndung.",
         "link": "#"
       }
    ]
  },
  "officials": {
    "pageTitle": "Amtsträger",
    "pageSubtitle": "Lernen Sie Ihre Vertreter kennen.",
    "cabinetTitle": "Das Kabinett",
    "governor": {
       "id": "g1",
       "name": "George Washington",
       "role": "Gouverneur",
       "description": "Gouverneur Washington dient dem Staat San Andreas seit 2020 mit Fokus auf wirtschaftliche Stabilität und öffentliche Sicherheit.",
       "imageUrl": "https://picsum.photos/id/1005/400/400",
       "extraInfo": "Amtszeit 2024-2028"
    },
    "cabinet": [
       {
         "id": "cab1",
         "name": "Sarah Connor",
         "role": "Justizministerin",
         "description": "Verantwortlich für das Justizsystem und die Staatsanwaltschaft.",
         "imageUrl": "https://picsum.photos/id/342/300/300",
         "extraInfo": ""
       },
       {
         "id": "cab2",
         "name": "James Gordon",
         "role": "Innenminister",
         "description": "Zuständig für die innere Sicherheit und Polizei.",
         "imageUrl": "https://picsum.photos/id/453/300/300",
         "extraInfo": ""
       }
    ]
  }
};
