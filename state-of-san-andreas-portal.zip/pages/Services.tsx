
import React from 'react';
import { useData } from '../context/DataContext';
import { 
  IdCard, Car, ShieldCheck, HeartHandshake, FileText, 
  Briefcase, Home, GraduationCap, Info, ExternalLink
} from 'lucide-react';

const Services: React.FC = () => {
  const { data } = useData();
  const { services } = data;

  // Simple icon mapping
  const getIcon = (iconName: string) => {
    switch (iconName) {
      case 'IdCard': return <IdCard size={32} />;
      case 'Car': return <Car size={32} />;
      case 'ShieldCheck': return <ShieldCheck size={32} />;
      case 'HeartHandshake': return <HeartHandshake size={32} />;
      case 'FileText': return <FileText size={32} />;
      case 'Briefcase': return <Briefcase size={32} />;
      case 'Home': return <Home size={32} />;
      case 'GraduationCap': return <GraduationCap size={32} />;
      default: return <Info size={32} />;
    }
  };

  return (
    <div className="min-h-screen bg-slate-50 dark:bg-slate-950 py-12 transition-colors duration-300">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        <div className="text-center mb-16">
          <h1 className="text-3xl md:text-4xl font-bold text-slate-900 dark:text-white mb-4">
            {services.pageTitle}
          </h1>
          <p className="text-lg text-slate-600 dark:text-slate-400 max-w-2xl mx-auto">
            {services.pageSubtitle}
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {services.items.map((service) => (
            <div key={service.id} className="bg-white dark:bg-slate-900 rounded-xl shadow-md p-8 border border-slate-100 dark:border-slate-800 hover:shadow-lg hover:border-blue-200 dark:hover:border-blue-800 transition-all group">
              <div className="bg-blue-50 dark:bg-blue-900/20 w-16 h-16 rounded-full flex items-center justify-center text-blue-600 dark:text-blue-400 mb-6 group-hover:scale-110 transition-transform duration-300">
                {getIcon(service.icon)}
              </div>
              <h3 className="text-xl font-bold text-slate-900 dark:text-white mb-3">
                {service.title}
              </h3>
              <p className="text-slate-600 dark:text-slate-400 mb-6 leading-relaxed">
                {service.description}
              </p>
              <button className="text-blue-600 dark:text-blue-400 font-medium inline-flex items-center gap-2 hover:underline">
                {service.linkText} <ExternalLink size={16} />
              </button>
            </div>
          ))}
        </div>
        
        {services.items.length === 0 && (
             <div className="text-center py-12 text-slate-500">Derzeit sind keine Online-Dienste verfügbar.</div>
        )}

      </div>
    </div>
  );
};

export default Services;
