
import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { useData } from '../context/DataContext';
import { Calendar, ChevronRight, Search, Archive as ArchiveIcon } from 'lucide-react';

const Archive: React.FC = () => {
  const { data } = useData();
  const { home, archive } = data;
  const [searchTerm, setSearchTerm] = useState('');

  const filteredNews = home.newsItems.filter(item => 
    item.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
    item.snippet.toLowerCase().includes(searchTerm.toLowerCase()) ||
    item.date.includes(searchTerm)
  );

  return (
    <div className="min-h-screen bg-slate-50 dark:bg-slate-950 py-12 transition-colors duration-300">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        <div className="flex flex-col md:flex-row md:items-end justify-between gap-6 mb-12 border-b border-slate-200 dark:border-slate-800 pb-8">
          <div>
            <div className="flex items-center gap-3 mb-2 text-slate-900 dark:text-white">
                <ArchiveIcon className="w-8 h-8 text-slate-400" />
                <h1 className="text-3xl md:text-4xl font-bold">
                    {archive.pageTitle}
                </h1>
            </div>
            <p className="text-lg text-slate-600 dark:text-slate-400 max-w-2xl">
              {archive.pageSubtitle}
            </p>
          </div>

          <div className="relative w-full md:w-auto">
            <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
              <Search className="h-5 w-5 text-slate-400" />
            </div>
            <input
              type="text"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              placeholder="Archiv durchsuchen..."
              className="block w-full md:w-80 pl-10 pr-4 py-3 border border-slate-300 dark:border-slate-700 rounded-lg leading-5 bg-white dark:bg-slate-900 text-slate-900 dark:text-white placeholder-slate-500 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition-all"
            />
          </div>
        </div>

        <div className="grid grid-cols-1 gap-6">
          {filteredNews.length > 0 ? (
            filteredNews.map((news) => (
                <div key={news.id} className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-lg p-6 shadow-sm hover:shadow-md transition-all flex flex-col md:flex-row gap-6 items-start">
                    <div className="flex-shrink-0 flex items-center text-sm text-slate-500 dark:text-slate-400 bg-slate-100 dark:bg-slate-800 px-3 py-1 rounded self-start">
                        <Calendar size={14} className="mr-2" />
                        {news.date}
                    </div>
                    <div className="flex-grow">
                        <h3 className="text-xl font-bold text-slate-900 dark:text-white mb-2">
                        <Link to={`/news/${news.id}`} className="hover:text-blue-600 dark:hover:text-blue-400 transition-colors">
                            {news.title}
                        </Link>
                        </h3>
                        <p className="text-slate-600 dark:text-slate-300 mb-4">
                            {news.snippet}
                        </p>
                        <Link 
                        to={`/news/${news.id}`}
                        className="text-blue-600 dark:text-blue-400 font-medium hover:underline text-sm inline-flex items-center gap-1"
                        >
                        Vollständigen Artikel lesen <ChevronRight size={16} />
                        </Link>
                    </div>
                </div>
            ))
          ) : (
            <div className="text-center py-20 bg-white dark:bg-slate-900 rounded-lg border border-dashed border-slate-300 dark:border-slate-700">
                <p className="text-slate-500 dark:text-slate-400 text-lg">Keine Nachrichten gefunden.</p>
                {searchTerm && <button onClick={() => setSearchTerm('')} className="mt-2 text-blue-600 hover:underline">Suche zurücksetzen</button>}
            </div>
          )}
        </div>

      </div>
    </div>
  );
};

export default Archive;
