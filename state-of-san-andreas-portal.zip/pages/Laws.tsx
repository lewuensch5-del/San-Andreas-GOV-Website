
import React from 'react';
import { useData } from '../context/DataContext';
import { BookOpen, ExternalLink, Scale } from 'lucide-react';

const Laws: React.FC = () => {
  const { data } = useData();
  const { laws } = data;

  return (
    <div className="min-h-screen bg-slate-50 dark:bg-slate-950 py-12 transition-colors duration-300">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        
        <div className="flex items-center justify-center gap-3 mb-6 text-slate-800 dark:text-white">
          <Scale size={40} />
          <h1 className="text-3xl md:text-4xl font-bold">
            {laws.pageTitle}
          </h1>
        </div>
        
        <p className="text-center text-slate-600 dark:text-slate-400 mb-12 text-lg">
          {laws.pageSubtitle}
        </p>

        <div className="space-y-6">
          {laws.items.map((law) => (
            <div key={law.id} className="bg-white dark:bg-slate-900 rounded-lg shadow-sm hover:shadow-md transition-all border-l-4 border-slate-900 dark:border-slate-600 p-6 flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
              <div className="flex-1">
                <div className="flex items-center gap-2 mb-2">
                  <BookOpen size={18} className="text-blue-600 dark:text-blue-400" />
                  <h3 className="text-xl font-bold text-slate-900 dark:text-white">{law.title}</h3>
                </div>
                <p className="text-slate-600 dark:text-slate-300 leading-relaxed">
                  {law.description}
                </p>
              </div>
              <div>
                <a 
                  href={law.link} 
                  target="_blank" 
                  rel="noopener noreferrer"
                  className="inline-flex items-center gap-2 px-4 py-2 bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-200 rounded-md font-medium transition-colors"
                >
                  Öffnen <ExternalLink size={16} />
                </a>
              </div>
            </div>
          ))}
        </div>

        <div className="mt-12 bg-blue-50 dark:bg-blue-900/20 border border-blue-100 dark:border-blue-900/30 rounded-lg p-6 text-center">
          <p className="text-sm text-blue-800 dark:text-blue-300">
            Hinweis: Die hier aufgeführten Gesetze entsprechen dem aktuellen Stand der Gesetzgebung von San Andreas.
            Änderungen durch den Kongress sind vorbehalten.
          </p>
        </div>
      </div>
    </div>
  );
};

export default Laws;
