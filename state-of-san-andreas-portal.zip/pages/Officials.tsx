
import React from 'react';
import { useData } from '../context/DataContext';

const Officials: React.FC = () => {
  const { data } = useData();
  const { officials } = data;

  return (
    <div className="min-h-screen bg-slate-50 dark:bg-slate-950 py-12 transition-colors duration-300">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Header */}
        <div className="text-center mb-16">
          <h1 className="text-3xl md:text-4xl font-bold text-slate-900 dark:text-white mb-4">
            {officials.pageTitle}
          </h1>
          <p className="text-lg text-slate-600 dark:text-slate-400 max-w-2xl mx-auto">
            {officials.pageSubtitle}
          </p>
        </div>

        {/* Governor Spotlight */}
        <div className="mb-20">
          <div className="bg-white dark:bg-slate-900 rounded-2xl shadow-xl overflow-hidden md:flex border border-slate-200 dark:border-slate-800 transition-colors">
            <div className="md:w-1/2 lg:w-2/5">
              <img 
                src={officials.governor.imageUrl} 
                alt={officials.governor.name}
                className="w-full h-full object-cover object-center min-h-[300px]"
              />
            </div>
            <div className="p-8 md:w-1/2 lg:w-3/5 flex flex-col justify-center bg-gradient-to-br from-slate-900 to-slate-800 text-white">
              <div className="uppercase tracking-wide text-sm text-yellow-500 font-semibold mb-2">
                {officials.governor.role}
              </div>
              <h2 className="block mt-1 text-3xl leading-tight font-bold mb-4">
                {officials.governor.name}
              </h2>
              <p className="text-slate-300 text-lg leading-relaxed mb-6">
                {officials.governor.description}
              </p>
              <div>
                {officials.governor.extraInfo && (
                  <span className="inline-block bg-blue-600 rounded-full px-4 py-1 text-sm font-semibold mr-2">
                    {officials.governor.extraInfo}
                  </span>
                )}
              </div>
            </div>
          </div>
        </div>

        {/* Cabinet Grid */}
        <h3 className="text-2xl font-bold text-slate-900 dark:text-white mb-8 border-b dark:border-slate-800 pb-4">
          {officials.cabinetTitle || "Kabinett"}
        </h3>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {officials.cabinet.map((member) => (
            <div key={member.id} className="bg-white dark:bg-slate-900 rounded-xl shadow-md overflow-hidden hover:shadow-lg transition-all duration-300 border border-slate-100 dark:border-slate-800 group">
              <div className="relative h-64 overflow-hidden">
                <img 
                  src={member.imageUrl} 
                  alt={member.name}
                  className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"
                />
                <div className="absolute bottom-0 left-0 right-0 bg-gradient-to-t from-black/80 to-transparent p-4">
                   <p className="text-yellow-400 font-medium text-sm">{member.role}</p>
                </div>
              </div>
              <div className="p-6">
                <h3 className="text-xl font-bold text-slate-900 dark:text-white mb-2">{member.name}</h3>
                {member.extraInfo && (
                   <span className="inline-block bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 text-xs px-2 py-1 rounded mb-2 font-medium">
                      {member.extraInfo}
                   </span>
                )}
                <p className="text-slate-600 dark:text-slate-400 text-sm">
                  {member.description}
                </p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default Officials;
