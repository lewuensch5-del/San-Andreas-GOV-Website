
import React from 'react';
import { useData } from '../context/DataContext';

const Congress: React.FC = () => {
  const { data } = useData();
  const { congress } = data;

  const getPartyColor = (party: string) => {
    if (party.includes('Demokraten')) return 'bg-blue-100 dark:bg-blue-900/30 text-blue-800 dark:text-blue-200 border-blue-200 dark:border-blue-800';
    if (party.includes('Republikaner')) return 'bg-red-100 dark:bg-red-900/30 text-red-800 dark:text-red-200 border-red-200 dark:border-red-800';
    return 'bg-gray-100 dark:bg-gray-800 text-gray-800 dark:text-gray-300 border-gray-200 dark:border-gray-700';
  };

  return (
    <div className="min-h-screen bg-slate-50 dark:bg-slate-950 py-12 transition-colors duration-300">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <h1 className="text-3xl md:text-4xl font-bold text-slate-900 dark:text-white mb-3">
            {congress.pageTitle}
          </h1>
          <p className="text-slate-600 dark:text-slate-400 max-w-2xl mx-auto">
            {congress.pageSubtitle}
          </p>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {congress.members.map((member) => (
            <div key={member.id} className="bg-white dark:bg-slate-900 rounded-lg shadow-sm border border-slate-200 dark:border-slate-800 p-4 flex flex-col items-center text-center hover:shadow-md transition-all">
              <div className="w-32 h-32 rounded-full overflow-hidden mb-4 ring-4 ring-slate-50 dark:ring-slate-800">
                <img 
                  src={member.imageUrl} 
                  alt={member.name} 
                  className="w-full h-full object-cover"
                />
              </div>
              <h3 className="text-lg font-bold text-slate-900 dark:text-white">{member.name}</h3>
              <p className="text-sm text-slate-500 dark:text-slate-400 mb-3">{member.district}</p>
              <span className={`px-3 py-1 rounded-full text-xs font-medium border ${getPartyColor(member.party)}`}>
                {member.party}
              </span>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default Congress;
