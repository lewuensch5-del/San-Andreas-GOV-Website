
import React from 'react';
import { useParams, Link, Navigate } from 'react-router-dom';
import { useData } from '../context/DataContext';
import { Calendar, ArrowLeft, Share2, Printer } from 'lucide-react';

const NewsDetail: React.FC = () => {
  const { id } = useParams<{ id: string }>();
  const { data } = useData();
  const newsItem = data.home.newsItems.find(item => item.id === id);

  if (!newsItem) {
    return <Navigate to="/" replace />;
  }

  return (
    <div className="min-h-screen bg-slate-50 dark:bg-slate-950 py-12 transition-colors duration-300">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Breadcrumb / Back Button */}
        <div className="mb-8">
          <Link 
            to="/" 
            className="inline-flex items-center text-slate-500 dark:text-slate-400 hover:text-blue-600 dark:hover:text-blue-400 transition-colors font-medium"
          >
            <ArrowLeft size={20} className="mr-2" />
            Zurück zur Übersicht
          </Link>
        </div>

        {/* Article Container */}
        <article className="bg-white dark:bg-slate-900 rounded-xl shadow-lg overflow-hidden border border-slate-200 dark:border-slate-800">
          
          {/* Header Image Area */}
          <div className="h-48 bg-gradient-to-r from-slate-900 to-slate-800 relative">
             <div className="absolute inset-0 opacity-20 bg-[url('https://www.transparenttextures.com/patterns/cubes.png')]"></div>
             <div className="absolute bottom-0 left-0 p-8 w-full bg-gradient-to-t from-black/60 to-transparent">
                <div className="flex items-center text-yellow-400 text-sm font-medium mb-2">
                  <Calendar size={16} className="mr-2" />
                  {newsItem.date}
                </div>
             </div>
          </div>

          <div className="p-8 md:p-12">
            <h1 className="text-3xl md:text-4xl font-bold text-slate-900 dark:text-white mb-6 leading-tight">
              {newsItem.title}
            </h1>

            {/* Meta Actions */}
            <div className="flex items-center gap-4 mb-8 border-b border-slate-100 dark:border-slate-800 pb-8">
              <button className="flex items-center gap-2 text-slate-500 dark:text-slate-400 hover:text-blue-600 dark:hover:text-blue-400 text-sm font-medium transition-colors">
                <Share2 size={16} /> Teilen
              </button>
              <button className="flex items-center gap-2 text-slate-500 dark:text-slate-400 hover:text-blue-600 dark:hover:text-blue-400 text-sm font-medium transition-colors">
                <Printer size={16} /> Drucken
              </button>
            </div>

            {/* Content */}
            <div className="prose prose-slate dark:prose-invert prose-lg max-w-none text-slate-700 dark:text-slate-300 leading-relaxed">
              <p className="font-medium text-xl text-slate-900 dark:text-white mb-6">
                {newsItem.snippet}
              </p>
              <div className="whitespace-pre-wrap">
                {newsItem.content}
              </div>
            </div>
            
            {/* Signature / Footer */}
            <div className="mt-12 pt-8 border-t border-slate-100 dark:border-slate-800 flex flex-col md:flex-row justify-between items-center gap-4">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-full bg-slate-200 dark:bg-slate-800 flex items-center justify-center text-slate-500 dark:text-slate-400 font-bold">
                  SA
                </div>
                <div>
                  <p className="text-sm font-bold text-slate-900 dark:text-white">Pressebüro San Andreas</p>
                  <p className="text-xs text-slate-500 dark:text-slate-400">Offizielle Mitteilung</p>
                </div>
              </div>
            </div>
          </div>
        </article>

        {/* Read Next Section */}
        <div className="mt-12">
          <h3 className="text-xl font-bold text-slate-900 dark:text-white mb-6">Weitere Nachrichten</h3>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {data.home.newsItems
              .filter(item => item.id !== id)
              .slice(0, 2)
              .map(item => (
                <Link 
                  key={item.id} 
                  to={`/news/${item.id}`}
                  className="block bg-white dark:bg-slate-900 p-6 rounded-lg shadow-sm border border-slate-200 dark:border-slate-800 hover:shadow-md hover:border-blue-300 dark:hover:border-blue-500 transition-all"
                >
                  <span className="text-xs text-slate-500 dark:text-slate-400 mb-2 block">{item.date}</span>
                  <h4 className="font-bold text-slate-900 dark:text-white mb-2">{item.title}</h4>
                  <span className="text-blue-600 dark:text-blue-400 text-sm font-medium">Lesen &rarr;</span>
                </Link>
            ))}
          </div>
        </div>

      </div>
    </div>
  );
};

export default NewsDetail;
