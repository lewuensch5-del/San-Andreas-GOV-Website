
import React from 'react';
import { Link } from 'react-router-dom';
import { useData } from '../context/DataContext';
import { Calendar, ChevronRight } from 'lucide-react';

const Home: React.FC = () => {
  const { data } = useData();
  const { home } = data;

  return (
    <div className="min-h-screen bg-slate-50 dark:bg-slate-950 transition-colors duration-300">
      {/* Hero Section */}
      <div className="relative h-[600px] w-full overflow-hidden bg-slate-900">
        <div className="absolute inset-0">
          <img
            src={home.heroImage}
            alt="San Andreas Landscape"
            className="w-full h-full object-cover opacity-50"
          />
        </div>
        <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-full flex flex-col justify-center items-center text-center md:items-start md:text-left">
          <img 
            src="https://static.wikia.nocookie.net/mtavg/images/9/94/San_Andreas_Seal.png/revision/latest?cb=20121107135013" 
            alt="State Seal" 
            className="h-32 w-32 md:h-40 md:w-40 mb-6 drop-shadow-2xl animate-in fade-in slide-in-from-bottom-4 duration-700"
          />
          <h2 className="text-yellow-500 font-bold tracking-widest uppercase mb-2 drop-shadow-md">
            {home.heroSubtitle}
          </h2>
          <h1 className="text-4xl md:text-6xl font-extrabold text-white tracking-tight drop-shadow-lg max-w-3xl">
            {home.heroTitle}
          </h1>
          <div className="mt-8">
            <Link to="/services" className="inline-block bg-blue-600 hover:bg-blue-700 text-white font-bold py-3 px-8 rounded-md shadow-lg transition duration-300 ease-in-out transform hover:-translate-y-1 border border-blue-500">
              Bürgerservice
            </Link>
          </div>
        </div>
      </div>

      {/* Welcome Section */}
      <div className="bg-white dark:bg-slate-900 py-16 shadow-sm transition-colors duration-300">
        <div className="max-w-4xl mx-auto px-4 text-center">
          <h2 className="text-3xl font-bold text-slate-900 dark:text-white mb-6">{home.welcomeTitle}</h2>
          <p className="text-xl text-slate-600 dark:text-slate-300 leading-relaxed">
            {home.welcomeText}
          </p>
          <div className="mt-8 w-24 h-1 bg-yellow-500 mx-auto rounded-full"></div>
        </div>
      </div>

      {/* News Section */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <div className="flex items-center justify-between mb-10">
          <h2 className="text-2xl font-bold text-slate-900 dark:text-white border-l-4 border-blue-600 pl-4">
            {home.newsTitle}
          </h2>
          <Link to="/archive" className="text-blue-600 dark:text-blue-400 hover:text-blue-800 font-medium flex items-center gap-1">
            Archiv <ChevronRight size={16} />
          </Link>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {home.newsItems.slice(0, 3).map((news) => (
            <div key={news.id} className="bg-white dark:bg-slate-900 dark:border-slate-800 border border-transparent rounded-lg shadow-md overflow-hidden hover:shadow-xl transition-all duration-300 flex flex-col h-full">
              <div className="p-6 flex-1">
                <div className="flex items-center text-sm text-slate-500 dark:text-slate-400 mb-3">
                  <Calendar size={14} className="mr-2" />
                  {news.date}
                </div>
                <h3 className="text-xl font-bold text-slate-900 dark:text-white mb-3 line-clamp-2">
                  {news.title}
                </h3>
                <p className="text-slate-600 dark:text-slate-300 text-sm leading-relaxed mb-4">
                  {news.snippet}
                </p>
              </div>
              <div className="px-6 pb-6 mt-auto">
                <Link 
                  to={`/news/${news.id}`}
                  className="text-blue-600 dark:text-blue-400 font-medium hover:underline text-sm inline-flex items-center gap-1"
                >
                  Weiterlesen <ChevronRight size={16} />
                </Link>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default Home;
