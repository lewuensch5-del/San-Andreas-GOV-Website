
import React, { useState, useEffect } from 'react';
import { useData } from '../context/DataContext';
import { 
  Save, RefreshCw, Plus, Trash2, 
  Image as ImageIcon, Type, Users, Scale, Building2, Lock, LogIn, Upload, Database, Wifi, WifiOff, Archive, FileText
} from 'lucide-react';
import { CongressMember, LawItem, BusinessEntry } from '../types';
import { isDbConnected } from '../services/firebaseConfig';

const Admin: React.FC = () => {
  const { 
    data, 
    updateHome, 
    updateOfficials, 
    updateCongress,
    updateLaws,
    updateBusiness,
    updateServices,
    updateArchive,
    updateFooter,
    updateHomeAndFooter, // New function
    resetData, 
    addNewsItem, 
    deleteNewsItem,
    refreshData
  } = useData();

  // Auth State
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [passwordInput, setPasswordInput] = useState('');
  const [loginError, setLoginError] = useState(false);
  const [isSaving, setIsSaving] = useState(false);

  const [activeTab, setActiveTab] = useState<'home' | 'news' | 'officials' | 'congress' | 'laws' | 'business' | 'services' | 'archive'>('home');

  // Local state for forms
  const [homeForm, setHomeForm] = useState(data.home);
  const [footerForm, setFooterForm] = useState(data.footer);
  const [officialsForm, setOfficialsForm] = useState(data.officials);
  const [congressForm, setCongressForm] = useState(data.congress);
  const [lawsForm, setLawsForm] = useState(data.laws);
  const [businessForm, setBusinessForm] = useState(data.business);
  const [servicesForm, setServicesForm] = useState(data.services);
  const [archiveForm, setArchiveForm] = useState(data.archive);

  // Sync local state with context data when data changes (from server)
  useEffect(() => {
    setHomeForm(data.home);
    setFooterForm(data.footer);
    setOfficialsForm(data.officials);
    setCongressForm(data.congress);
    setLawsForm(data.laws);
    setBusinessForm(data.business);
    setServicesForm(data.services);
    setArchiveForm(data.archive);
  }, [data]);

  // Login Handler
  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    if (passwordInput === 'admin') {
      setIsAuthenticated(true);
      setLoginError(false);
    } else {
      setLoginError(true);
    }
  };

  // --- Image Upload Helper ---
  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>, callback: (url: string) => void) => {
    const file = e.target.files?.[0];
    if (file) {
      if (file.size > 2 * 1024 * 1024) {
        alert("Warnung: Das Bild ist sehr groß (>2MB). Bitte verwenden Sie komprimierte Bilder.");
      }
      const reader = new FileReader();
      reader.onloadend = () => {
        if (typeof reader.result === 'string') {
          callback(reader.result);
        }
      };
      reader.readAsDataURL(file);
    }
  };

  // --- Generic Save Wrapper ---
  const performSave = async (saveFn: () => Promise<void>, successMessage: string) => {
    setIsSaving(true);
    try {
        await saveFn();
        alert(successMessage);
    } catch (error: any) {
        console.error("Save failed", error);
        if (error.message && error.message.includes("Missing or insufficient permissions")) {
             alert("FEHLER: Keine Schreibrechte! Bitte prüfen Sie die 'Firestore Rules' in der Firebase Console.");
        } else {
             alert(`Fehler beim Speichern: ${error.message}`);
        }
    } finally {
        setIsSaving(false);
    }
  };

  // --- Handlers ---
  // FIXED: Use updateHomeAndFooter to avoid race conditions
  const handleHomeSave = () => performSave(async () => {
      await updateHomeAndFooter(homeForm, footerForm);
  }, 'Startseite & Footer erfolgreich für alle Benutzer gespeichert!');

  const handleOfficialsSave = () => performSave(async () => updateOfficials(officialsForm), 'Amtsträger gespeichert!');
  const handleCongressSave = () => performSave(async () => updateCongress(congressForm), 'Kongress gespeichert!');
  const handleLawsSave = () => performSave(async () => updateLaws(lawsForm), 'Gesetze gespeichert!');
  const handleBusinessSave = () => performSave(async () => updateBusiness(businessForm), 'Gewerberegister gespeichert!');
  const handleServicesSave = () => performSave(async () => updateServices(servicesForm), 'Bürgerservice gespeichert!');
  const handleArchiveSave = () => performSave(async () => updateArchive(archiveForm), 'Archiv-Einstellungen gespeichert!');

  // --- Helpers (News, Congress, Laws, Business) ---
  const handleNewNews = () => {
    performSave(async () => addNewsItem({
      id: Date.now().toString(),
      title: "Neue Nachricht",
      date: new Date().toLocaleDateString('de-DE'),
      snippet: "Kurzbeschreibung...",
      content: "Inhalt..."
    }), "Neue Nachricht angelegt.");
  };

  const addCongressMember = () => {
    setCongressForm({
      ...congressForm,
      members: [...congressForm.members, {
        id: Date.now().toString(),
        name: "Neues Mitglied",
        party: "Partei",
        district: "Bezirk",
        imageUrl: "https://picsum.photos/300/300"
      }]
    });
  };

  const removeCongressMember = (id: string) => {
    setCongressForm({
      ...congressForm,
      members: congressForm.members.filter(m => m.id !== id)
    });
  };

  const addLaw = () => {
    setLawsForm({
      ...lawsForm,
      items: [...lawsForm.items, {
        id: Date.now().toString(),
        title: "Neues Gesetz",
        description: "Beschreibung...",
        link: "#"
      }]
    });
  };

  const removeLaw = (id: string) => {
    setLawsForm({ ...lawsForm, items: lawsForm.items.filter(l => l.id !== id) });
  };

  const addBusiness = () => {
    setBusinessForm({
      ...businessForm,
      registry: [...businessForm.registry, {
        id: Date.now().toString(),
        name: "Neues Unternehmen",
        type: "Gewerbeart",
        owner: "Inhaber",
        status: "Active",
        registeredDate: new Date().toLocaleDateString('de-DE'),
        expiryDate: "01.01.2030"
      }]
    });
  };

  const removeBusiness = (id: string) => {
    setBusinessForm({ ...businessForm, registry: businessForm.registry.filter(b => b.id !== id) });
  };
  
  const addService = () => {
    setServicesForm({
      ...servicesForm,
      items: [...servicesForm.items, {
        id: Date.now().toString(),
        title: "Neuer Dienst",
        description: "Beschreibung...",
        icon: "Info",
        linkText: "Link"
      }]
    });
  };

  const removeService = (id: string) => {
    setServicesForm({ ...servicesForm, items: servicesForm.items.filter(i => i.id !== id) });
  };

  // --- Helpers (Officials) ---
  const addCabinetMember = () => {
    setOfficialsForm({
      ...officialsForm,
      cabinet: [...officialsForm.cabinet, {
        id: Date.now().toString(),
        name: "Neues Mitglied",
        role: "Minister",
        description: "Beschreibung...",
        imageUrl: "https://picsum.photos/400/400",
        extraInfo: ""
      }]
    });
  };

  const removeCabinetMember = (id: string) => {
    setOfficialsForm({
      ...officialsForm,
      cabinet: officialsForm.cabinet.filter(m => m.id !== id)
    });
  };


  // --- LOGIN SCREEN ---
  if (!isAuthenticated) {
    return (
      <div className="min-h-screen bg-slate-100 dark:bg-slate-900 flex items-center justify-center p-4 transition-colors">
        <div className="bg-white dark:bg-slate-800 p-8 rounded-lg shadow-xl w-full max-w-md flex flex-col items-center">
          <div className="mb-6">
            <img 
                src="https://static.wikia.nocookie.net/mtavg/images/9/94/San_Andreas_Seal.png/revision/latest?cb=20121107135013" 
                alt="State Seal" 
                className="w-24 h-24 drop-shadow-md"
            />
          </div>
          <h2 className="text-2xl font-bold text-center text-slate-800 dark:text-white mb-2">Admin Login</h2>
          <p className="text-center text-slate-500 dark:text-slate-400 mb-6">Bitte authentifizieren Sie sich für den Zugriff.</p>
          <form onSubmit={handleLogin} className="w-full">
            <div className="mb-4">
              <input
                type="password"
                value={passwordInput}
                onChange={(e) => setPasswordInput(e.target.value)}
                placeholder="Passwort eingeben"
                className={`w-full p-3 border rounded-md outline-none focus:ring-2 transition-all dark:bg-slate-700 dark:text-white ${loginError ? 'border-red-500 focus:ring-red-200' : 'border-slate-300 dark:border-slate-600 focus:ring-blue-200'}`}
                autoFocus
              />
              {loginError && <p className="text-red-500 text-sm mt-2">Falsches Passwort.</p>}
            </div>
            <button type="submit" className="w-full bg-slate-900 hover:bg-slate-800 text-white font-bold py-3 rounded-md transition-colors flex justify-center items-center gap-2">
              <LogIn size={18} /> Anmelden
            </button>
          </form>
        </div>
      </div>
    );
  }

  // --- ADMIN INTERFACE ---
  return (
    <div className="min-h-screen bg-slate-100 dark:bg-slate-950 pb-12 transition-colors">
      {/* Top Bar */}
      <div className="bg-slate-900 dark:bg-black text-white py-4 shadow-lg sticky top-16 z-40">
        <div className="max-w-7xl mx-auto px-4 flex flex-col sm:flex-row justify-between items-center gap-4">
          <div className="flex items-center gap-3">
            <div className="bg-yellow-500 p-1 rounded text-slate-900 font-bold text-xs">ADMIN</div>
            <h1 className="text-xl font-bold">CMS</h1>
            
            {/* DB Connection Status */}
            <div className={`flex items-center gap-1 px-3 py-1 rounded-full text-xs font-medium border ${isDbConnected ? 'bg-green-900/50 border-green-500 text-green-300' : 'bg-gray-800 border-gray-600 text-gray-400'}`}>
               {isDbConnected ? <Wifi size={12} /> : <WifiOff size={12} />}
               {isDbConnected ? 'Datenbank Aktiv' : 'Lokalmodus'}
            </div>
          </div>
          <div className="flex gap-3">
            <button onClick={refreshData} className="flex items-center gap-2 bg-slate-700 hover:bg-slate-600 px-3 py-2 rounded text-sm">
              <RefreshCw size={16} /> Sync
            </button>
            <button onClick={() => resetData().catch(e => alert(e))} className="flex items-center gap-2 bg-red-600 hover:bg-red-700 px-3 py-2 rounded text-sm">
              Reset DB
            </button>
            <button onClick={() => setIsAuthenticated(false)} className="flex items-center gap-2 bg-slate-700 hover:bg-slate-600 px-3 py-2 rounded text-sm">
              Logout
            </button>
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 mt-8 grid grid-cols-1 lg:grid-cols-4 gap-8">
        
        {/* Sidebar Navigation */}
        <div className="lg:col-span-1">
          <div className="bg-white dark:bg-slate-900 rounded-lg shadow p-2 sticky top-40 border dark:border-slate-800">
            <button onClick={() => setActiveTab('home')} className={`w-full text-left px-4 py-3 rounded-md mb-1 font-medium flex items-center gap-3 transition-colors ${activeTab === 'home' ? 'bg-blue-50 dark:bg-slate-800 text-blue-700 dark:text-blue-400' : 'text-slate-600 dark:text-slate-400 hover:bg-slate-50 dark:hover:bg-slate-800'}`}>
              <ImageIcon size={18} /> Startseite
            </button>
            <button onClick={() => setActiveTab('news')} className={`w-full text-left px-4 py-3 rounded-md mb-1 font-medium flex items-center gap-3 transition-colors ${activeTab === 'news' ? 'bg-blue-50 dark:bg-slate-800 text-blue-700 dark:text-blue-400' : 'text-slate-600 dark:text-slate-400 hover:bg-slate-50 dark:hover:bg-slate-800'}`}>
              <Type size={18} /> Nachrichten
            </button>
            <button onClick={() => setActiveTab('services')} className={`w-full text-left px-4 py-3 rounded-md mb-1 font-medium flex items-center gap-3 transition-colors ${activeTab === 'services' ? 'bg-blue-50 dark:bg-slate-800 text-blue-700 dark:text-blue-400' : 'text-slate-600 dark:text-slate-400 hover:bg-slate-50 dark:hover:bg-slate-800'}`}>
              <FileText size={18} /> Bürgerservice
            </button>
            <button onClick={() => setActiveTab('officials')} className={`w-full text-left px-4 py-3 rounded-md mb-1 font-medium flex items-center gap-3 transition-colors ${activeTab === 'officials' ? 'bg-blue-50 dark:bg-slate-800 text-blue-700 dark:text-blue-400' : 'text-slate-600 dark:text-slate-400 hover:bg-slate-50 dark:hover:bg-slate-800'}`}>
              <Users size={18} /> Amtsträger
            </button>
            <button onClick={() => setActiveTab('congress')} className={`w-full text-left px-4 py-3 rounded-md mb-1 font-medium flex items-center gap-3 transition-colors ${activeTab === 'congress' ? 'bg-blue-50 dark:bg-slate-800 text-blue-700 dark:text-blue-400' : 'text-slate-600 dark:text-slate-400 hover:bg-slate-50 dark:hover:bg-slate-800'}`}>
              <Users size={18} /> Kongress
            </button>
            <button onClick={() => setActiveTab('laws')} className={`w-full text-left px-4 py-3 rounded-md mb-1 font-medium flex items-center gap-3 transition-colors ${activeTab === 'laws' ? 'bg-blue-50 dark:bg-slate-800 text-blue-700 dark:text-blue-400' : 'text-slate-600 dark:text-slate-400 hover:bg-slate-50 dark:hover:bg-slate-800'}`}>
              <Scale size={18} /> Gesetze
            </button>
            <button onClick={() => setActiveTab('business')} className={`w-full text-left px-4 py-3 rounded-md mb-1 font-medium flex items-center gap-3 transition-colors ${activeTab === 'business' ? 'bg-blue-50 dark:bg-slate-800 text-blue-700 dark:text-blue-400' : 'text-slate-600 dark:text-slate-400 hover:bg-slate-50 dark:hover:bg-slate-800'}`}>
              <Building2 size={18} /> Gewerbe
            </button>
            <button onClick={() => setActiveTab('archive')} className={`w-full text-left px-4 py-3 rounded-md mb-1 font-medium flex items-center gap-3 transition-colors ${activeTab === 'archive' ? 'bg-blue-50 dark:bg-slate-800 text-blue-700 dark:text-blue-400' : 'text-slate-600 dark:text-slate-400 hover:bg-slate-50 dark:hover:bg-slate-800'}`}>
              <Archive size={18} /> Archiv
            </button>
            
            {!isDbConnected && (
               <div className="mt-4 p-3 bg-yellow-50 border border-yellow-200 rounded text-xs text-yellow-800 dark:bg-yellow-900/20 dark:text-yellow-200 dark:border-yellow-800">
                  <strong>Hinweis:</strong> Es ist keine Datenbank verbunden. Änderungen werden nur lokal in Ihrem Browser gespeichert.
               </div>
            )}
          </div>
        </div>

        {/* Main Content Editor */}
        <div className="lg:col-span-3">
          
          {/* --- HOME TAB --- */}
          {activeTab === 'home' && (
            <div className="bg-white dark:bg-slate-900 rounded-lg shadow p-6 animate-in fade-in duration-300 border dark:border-slate-800">
              <h2 className="text-xl font-bold mb-6 border-b dark:border-slate-700 pb-4 text-slate-800 dark:text-white">Startseite Bearbeiten</h2>
              <div className="space-y-6">
                <div className="grid grid-cols-1 gap-6">
                    <div>
                        <label className="block text-sm font-bold text-slate-700 dark:text-slate-300 mb-1">Hero Titel</label>
                        <input type="text" value={homeForm.heroTitle} onChange={(e) => setHomeForm({...homeForm, heroTitle: e.target.value})} className="w-full border border-slate-300 dark:border-slate-600 rounded p-2 dark:bg-slate-800 dark:text-white" />
                    </div>
                    <div>
                        <label className="block text-sm font-bold text-slate-700 dark:text-slate-300 mb-1">Hero Untertitel</label>
                        <input type="text" value={homeForm.heroSubtitle} onChange={(e) => setHomeForm({...homeForm, heroSubtitle: e.target.value})} className="w-full border border-slate-300 dark:border-slate-600 rounded p-2 dark:bg-slate-800 dark:text-white" />
                    </div>
                    <div>
                        <label className="block text-sm font-bold text-slate-700 dark:text-slate-300 mb-1">Hero Bild</label>
                        <div className="flex gap-2">
                          <input type="text" value={homeForm.heroImage} onChange={(e) => setHomeForm({...homeForm, heroImage: e.target.value})} className="flex-grow border border-slate-300 dark:border-slate-600 rounded p-2 font-mono text-sm dark:bg-slate-800 dark:text-white" placeholder="Bild URL oder Upload" />
                          <label className="flex items-center justify-center px-3 py-2 bg-slate-200 dark:bg-slate-700 hover:bg-slate-300 rounded cursor-pointer text-slate-700 dark:text-slate-300 transition-colors" title="Bild hochladen">
                            <Upload size={18} />
                            <input type="file" className="hidden" accept="image/*" onChange={(e) => handleImageUpload(e, (url) => setHomeForm({...homeForm, heroImage: url}))} />
                          </label>
                        </div>
                    </div>
                    <div className="border-t dark:border-slate-700 pt-4">
                        <label className="block text-sm font-bold text-slate-700 dark:text-slate-300 mb-1">Willkommen Titel</label>
                        <input type="text" value={homeForm.welcomeTitle} onChange={(e) => setHomeForm({...homeForm, welcomeTitle: e.target.value})} className="w-full border border-slate-300 dark:border-slate-600 rounded p-2 dark:bg-slate-800 dark:text-white" />
                    </div>
                    <div>
                        <label className="block text-sm font-bold text-slate-700 dark:text-slate-300 mb-1">Willkommen Text</label>
                        <textarea rows={4} value={homeForm.welcomeText} onChange={(e) => setHomeForm({...homeForm, welcomeText: e.target.value})} className="w-full border border-slate-300 dark:border-slate-600 rounded p-2 dark:bg-slate-800 dark:text-white" />
                    </div>
                     <div>
                        <label className="block text-sm font-bold text-slate-700 dark:text-slate-300 mb-1">Nachrichten Bereich Titel</label>
                        <input type="text" value={homeForm.newsTitle} onChange={(e) => setHomeForm({...homeForm, newsTitle: e.target.value})} className="w-full border border-slate-300 dark:border-slate-600 rounded p-2 dark:bg-slate-800 dark:text-white" />
                    </div>
                    
                    <div className="border-t dark:border-slate-700 pt-4">
                        <h3 className="font-bold text-slate-800 dark:text-white mb-3">Footer (Fußzeile)</h3>
                        <div>
                            <label className="block text-sm font-bold text-slate-700 dark:text-slate-300 mb-1">Footer Titel</label>
                            <input type="text" value={footerForm.title} onChange={(e) => setFooterForm({...footerForm, title: e.target.value})} className="w-full border border-slate-300 dark:border-slate-600 rounded p-2 dark:bg-slate-800 dark:text-white" />
                        </div>
                        <div className="mt-2">
                            <label className="block text-sm font-bold text-slate-700 dark:text-slate-300 mb-1">Copyright Text</label>
                            <input type="text" value={footerForm.copyrightText} onChange={(e) => setFooterForm({...footerForm, copyrightText: e.target.value})} className="w-full border border-slate-300 dark:border-slate-600 rounded p-2 dark:bg-slate-800 dark:text-white" />
                        </div>
                    </div>
                </div>
                <div className="flex justify-end pt-4">
                  <button onClick={handleHomeSave} disabled={isSaving} className="flex items-center gap-2 bg-blue-600 text-white px-6 py-2 rounded hover:bg-blue-700 shadow-sm disabled:opacity-50 disabled:cursor-not-allowed">
                    {isSaving ? <RefreshCw className="animate-spin" size={18} /> : <Save size={18} />} 
                    {isSaving ? 'Speichere...' : 'Speichern'}
                  </button>
                </div>
              </div>
            </div>
          )}

          {/* --- NEWS TAB --- */}
          {activeTab === 'news' && (
            <div className="bg-white dark:bg-slate-900 rounded-lg shadow p-6 animate-in fade-in duration-300 border dark:border-slate-800">
              <div className="flex justify-between items-center mb-6 border-b dark:border-slate-700 pb-4">
                <h2 className="text-xl font-bold text-slate-800 dark:text-white">Nachrichten</h2>
                <button onClick={handleNewNews} disabled={isSaving} className="flex items-center gap-2 bg-green-600 text-white px-4 py-2 rounded text-sm hover:bg-green-700 shadow-sm disabled:opacity-50"><Plus size={16} /> Neu</button>
              </div>
              <div className="space-y-6">
                {data.home.newsItems.map((news, index) => (
                  <div key={news.id} className="border border-slate-200 dark:border-slate-700 rounded-lg p-4 bg-slate-50 dark:bg-slate-800 hover:shadow-md transition-shadow">
                    <div className="space-y-3">
                      <input type="text" value={news.title} onChange={(e) => { const newItems = [...data.home.newsItems]; newItems[index].title = e.target.value; updateHome({...data.home, newsItems: newItems}); }} className="w-full font-bold text-lg border-b dark:border-slate-600 bg-transparent outline-none pb-1 dark:text-white" placeholder="Titel" />
                      <input type="text" value={news.date} onChange={(e) => { const newItems = [...data.home.newsItems]; newItems[index].date = e.target.value; updateHome({...data.home, newsItems: newItems}); }} className="w-full text-sm text-slate-500 dark:text-slate-400 border-b dark:border-slate-600 bg-transparent" placeholder="Datum" />
                      <textarea value={news.snippet} onChange={(e) => { const newItems = [...data.home.newsItems]; newItems[index].snippet = e.target.value; updateHome({...data.home, newsItems: newItems}); }} className="w-full text-sm border dark:border-slate-600 p-2 rounded bg-transparent dark:text-slate-300" placeholder="Vorschau" rows={2} />
                      <textarea value={news.content} onChange={(e) => { const newItems = [...data.home.newsItems]; newItems[index].content = e.target.value; updateHome({...data.home, newsItems: newItems}); }} className="w-full text-sm border dark:border-slate-600 p-2 rounded bg-transparent dark:text-slate-300" placeholder="Inhalt" rows={4} />
                    </div>
                    <div className="flex justify-end mt-3">
                      <button onClick={() => performSave(async () => deleteNewsItem(news.id), "Nachricht gelöscht")} className="text-red-500 hover:text-red-700 text-sm flex items-center gap-1"><Trash2 size={14} /> Löschen</button>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* --- SERVICES TAB --- */}
          {activeTab === 'services' && (
            <div className="bg-white dark:bg-slate-900 rounded-lg shadow p-6 animate-in fade-in duration-300 border dark:border-slate-800">
              <div className="flex justify-between items-center mb-6 border-b dark:border-slate-700 pb-4">
                <h2 className="text-xl font-bold text-slate-800 dark:text-white">Bürgerservice Bearbeiten</h2>
                <button onClick={addService} className="flex items-center gap-2 bg-green-600 text-white px-4 py-2 rounded text-sm hover:bg-green-700 shadow-sm"><Plus size={16} /> Dienstleistung</button>
              </div>
              
              <div className="mb-6 grid gap-4">
                  <div>
                    <label className="block text-xs font-bold text-slate-500 dark:text-slate-400 uppercase mb-1">Seitentitel</label>
                    <input type="text" value={servicesForm.pageTitle} onChange={(e) => setServicesForm({...servicesForm, pageTitle: e.target.value})} className="w-full border border-slate-300 dark:border-slate-600 rounded p-2 dark:bg-slate-800 dark:text-white" />
                  </div>
                  <div>
                    <label className="block text-xs font-bold text-slate-500 dark:text-slate-400 uppercase mb-1">Untertitel</label>
                    <input type="text" value={servicesForm.pageSubtitle} onChange={(e) => setServicesForm({...servicesForm, pageSubtitle: e.target.value})} className="w-full border border-slate-300 dark:border-slate-600 rounded p-2 dark:bg-slate-800 dark:text-white" />
                  </div>
              </div>

              <div className="space-y-4">
                {servicesForm.items.map((item, idx) => (
                  <div key={item.id} className="border dark:border-slate-700 p-4 rounded-lg bg-slate-50 dark:bg-slate-800 relative">
                     <div className="grid gap-3">
                       <div className="flex gap-3">
                         <input type="text" value={item.title} onChange={(e) => { const s = [...servicesForm.items]; s[idx].title = e.target.value; setServicesForm({...servicesForm, items: s}); }} className="flex-1 border border-slate-300 dark:border-slate-600 p-2 rounded font-bold dark:bg-slate-700 dark:text-white" placeholder="Titel" />
                         <input type="text" value={item.linkText} onChange={(e) => { const s = [...servicesForm.items]; s[idx].linkText = e.target.value; setServicesForm({...servicesForm, items: s}); }} className="w-1/3 border border-slate-300 dark:border-slate-600 p-2 rounded text-sm text-blue-600 dark:text-blue-400 dark:bg-slate-700" placeholder="Button Text" />
                       </div>
                       <textarea value={item.description} onChange={(e) => { const s = [...servicesForm.items]; s[idx].description = e.target.value; setServicesForm({...servicesForm, items: s}); }} className="w-full border border-slate-300 dark:border-slate-600 p-2 rounded dark:bg-slate-700 dark:text-white" rows={2} placeholder="Beschreibung" />
                       <div className="text-xs text-slate-400">
                            Icon Name (Lucide React): 
                            <input type="text" value={item.icon} onChange={(e) => { const s = [...servicesForm.items]; s[idx].icon = e.target.value; setServicesForm({...servicesForm, items: s}); }} className="ml-2 border border-slate-300 dark:border-slate-600 p-1 rounded dark:bg-slate-700 dark:text-white inline-block w-32" placeholder="z.B. Car, Home" />
                       </div>
                     </div>
                     <button onClick={() => removeService(item.id)} className="absolute top-4 right-2 text-red-400 hover:text-red-600 p-1"><Trash2 size={16} /></button>
                  </div>
                ))}
              </div>
              <div className="flex justify-end pt-6">
                  <button onClick={handleServicesSave} disabled={isSaving} className="flex items-center gap-2 bg-blue-600 text-white px-6 py-2 rounded hover:bg-blue-700 shadow-sm disabled:opacity-50">
                    {isSaving ? <RefreshCw className="animate-spin" size={18} /> : <Save size={18} />} Speichern
                  </button>
              </div>
            </div>
          )}

           {/* --- ARCHIVE TAB --- */}
           {activeTab === 'archive' && (
            <div className="bg-white dark:bg-slate-900 rounded-lg shadow p-6 animate-in fade-in duration-300 border dark:border-slate-800">
              <h2 className="text-xl font-bold mb-6 border-b dark:border-slate-700 pb-4 text-slate-800 dark:text-white">Archiv Einstellungen</h2>
              <div className="mb-6 grid gap-4">
                  <div>
                    <label className="block text-xs font-bold text-slate-500 dark:text-slate-400 uppercase mb-1">Seitentitel</label>
                    <input type="text" value={archiveForm.pageTitle} onChange={(e) => setArchiveForm({...archiveForm, pageTitle: e.target.value})} className="w-full border border-slate-300 dark:border-slate-600 rounded p-2 dark:bg-slate-800 dark:text-white" />
                  </div>
                  <div>
                    <label className="block text-xs font-bold text-slate-500 dark:text-slate-400 uppercase mb-1">Untertitel</label>
                    <input type="text" value={archiveForm.pageSubtitle} onChange={(e) => setArchiveForm({...archiveForm, pageSubtitle: e.target.value})} className="w-full border border-slate-300 dark:border-slate-600 rounded p-2 dark:bg-slate-800 dark:text-white" />
                  </div>
              </div>
              <p className="text-sm text-slate-500">Hinweis: Das Archiv zeigt automatisch alle Nachrichten an, die im Reiter "Nachrichten" erstellt wurden.</p>
              <div className="flex justify-end pt-6">
                  <button onClick={handleArchiveSave} disabled={isSaving} className="flex items-center gap-2 bg-blue-600 text-white px-6 py-2 rounded hover:bg-blue-700 shadow-sm disabled:opacity-50">
                    {isSaving ? <RefreshCw className="animate-spin" size={18} /> : <Save size={18} />} Speichern
                  </button>
              </div>
            </div>
          )}

          {/* --- OFFICIALS TAB --- */}
          {activeTab === 'officials' && (
            <div className="bg-white dark:bg-slate-900 rounded-lg shadow p-6 animate-in fade-in duration-300 border dark:border-slate-800">
              <h2 className="text-xl font-bold mb-6 border-b dark:border-slate-700 pb-4 text-slate-800 dark:text-white">Amtsträger Bearbeiten</h2>
              
               <div className="mb-8 grid gap-4">
                  <div>
                    <label className="block text-xs font-bold text-slate-500 dark:text-slate-400 uppercase mb-1">Seitentitel</label>
                    <input type="text" value={officialsForm.pageTitle} onChange={(e) => setOfficialsForm({...officialsForm, pageTitle: e.target.value})} className="w-full border border-slate-300 dark:border-slate-600 rounded p-2 dark:bg-slate-800 dark:text-white" />
                  </div>
                  <div>
                    <label className="block text-xs font-bold text-slate-500 dark:text-slate-400 uppercase mb-1">Untertitel</label>
                    <input type="text" value={officialsForm.pageSubtitle} onChange={(e) => setOfficialsForm({...officialsForm, pageSubtitle: e.target.value})} className="w-full border border-slate-300 dark:border-slate-600 rounded p-2 dark:bg-slate-800 dark:text-white" />
                  </div>
              </div>

              <div className="mb-8 border dark:border-slate-700 rounded-lg p-4 bg-slate-50 dark:bg-slate-800">
                <h3 className="font-bold text-blue-800 dark:text-blue-400 mb-4 uppercase text-xs tracking-wider">Hauptamtsträger (z.B. Gouverneur)</h3>
                <div className="grid gap-4">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div>
                            <label className="block text-xs font-bold text-slate-500 dark:text-slate-400 uppercase mb-1">Name</label>
                            <input type="text" value={officialsForm.governor.name} onChange={(e) => setOfficialsForm({...officialsForm, governor: { ...officialsForm.governor, name: e.target.value }})} className="w-full border border-slate-300 dark:border-slate-600 rounded p-2 font-bold dark:bg-slate-700 dark:text-white" placeholder="Name" />
                        </div>
                        <div>
                            <label className="block text-xs font-bold text-slate-500 dark:text-slate-400 uppercase mb-1">Amtsbezeichnung</label>
                            <input type="text" value={officialsForm.governor.role} onChange={(e) => setOfficialsForm({...officialsForm, governor: { ...officialsForm.governor, role: e.target.value }})} className="w-full border border-slate-300 dark:border-slate-600 rounded p-2 dark:bg-slate-700 dark:text-white" placeholder="z.B. Gouverneur" />
                        </div>
                    </div>
                    
                    <div>
                        <label className="block text-xs font-bold text-slate-500 dark:text-slate-400 uppercase mb-1">Zusatzinfo / Amtszeit</label>
                        <input type="text" value={officialsForm.governor.extraInfo || ''} onChange={(e) => setOfficialsForm({...officialsForm, governor: { ...officialsForm.governor, extraInfo: e.target.value }})} className="w-full border border-slate-300 dark:border-slate-600 rounded p-2 dark:bg-slate-700 dark:text-white" placeholder="z.B. Amtszeit 2020-2024" />
                    </div>

                    <div>
                        <label className="block text-xs font-bold text-slate-500 dark:text-slate-400 uppercase mb-1">Bild</label>
                        <div className="flex gap-2">
                        <input type="text" value={officialsForm.governor.imageUrl} onChange={(e) => setOfficialsForm({...officialsForm, governor: { ...officialsForm.governor, imageUrl: e.target.value }})} className="flex-grow border border-slate-300 dark:border-slate-600 rounded p-2 font-mono text-xs dark:bg-slate-700 dark:text-white" placeholder="Bild URL" />
                        <label className="flex items-center justify-center px-3 py-2 bg-slate-200 dark:bg-slate-600 hover:bg-slate-300 rounded cursor-pointer text-slate-700 dark:text-slate-300 transition-colors">
                            <Upload size={16} />
                            <input type="file" className="hidden" accept="image/*" onChange={(e) => handleImageUpload(e, (url) => setOfficialsForm({...officialsForm, governor: { ...officialsForm.governor, imageUrl: url }}))} />
                        </label>
                        </div>
                    </div>
                    <div>
                        <label className="block text-xs font-bold text-slate-500 dark:text-slate-400 uppercase mb-1">Beschreibung</label>
                        <textarea value={officialsForm.governor.description} onChange={(e) => setOfficialsForm({...officialsForm, governor: { ...officialsForm.governor, description: e.target.value }})} className="w-full border border-slate-300 dark:border-slate-600 rounded p-2 dark:bg-slate-700 dark:text-white" rows={3} placeholder="Beschreibung" />
                    </div>
                </div>
              </div>

              <div className="space-y-6">
                <div className="flex justify-between items-center border-b dark:border-slate-700 pb-2">
                    <h3 className="font-bold text-blue-800 dark:text-blue-400 uppercase text-xs tracking-wider">Kabinett & Weitere Amtsträger</h3>
                    <button onClick={addCabinetMember} className="flex items-center gap-1 bg-green-600 text-white px-3 py-1 rounded text-xs hover:bg-green-700"><Plus size={14} /> Hinzufügen</button>
                </div>
                
                {/* Cabinet Title Edit */}
                <div className="mb-4">
                  <label className="block text-xs font-bold text-slate-500 dark:text-slate-400 uppercase mb-1">Titel für Kabinett-Sektion</label>
                  <input 
                    type="text" 
                    value={officialsForm.cabinetTitle || ''} 
                    onChange={(e) => setOfficialsForm({...officialsForm, cabinetTitle: e.target.value})} 
                    className="w-full border border-slate-300 dark:border-slate-600 rounded p-2 dark:bg-slate-800 dark:text-white" 
                    placeholder="z.B. Kabinett, Senat, Mitarbeiter" 
                  />
                </div>

                   {officialsForm.cabinet.map((member, idx) => (
                     <div key={member.id} className="border dark:border-slate-700 p-4 rounded-lg relative bg-white dark:bg-slate-800">
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-2">
                          <div>
                             <label className="block text-xs text-slate-400 mb-1">Name</label>
                             <input type="text" value={member.name} onChange={(e) => { const newCab = [...officialsForm.cabinet]; newCab[idx].name = e.target.value; setOfficialsForm({...officialsForm, cabinet: newCab}); }} className="w-full font-bold border border-slate-300 dark:border-slate-600 p-1 rounded dark:bg-slate-700 dark:text-white" placeholder="Name" />
                          </div>
                          <div>
                             <label className="block text-xs text-slate-400 mb-1">Rolle / Amt</label>
                             <input type="text" value={member.role} onChange={(e) => { const newCab = [...officialsForm.cabinet]; newCab[idx].role = e.target.value; setOfficialsForm({...officialsForm, cabinet: newCab}); }} className="w-full text-slate-600 dark:text-slate-300 border border-slate-300 dark:border-slate-600 p-1 rounded dark:bg-slate-700" placeholder="Rolle" />
                          </div>
                        </div>
                        <div className="mb-2">
                           <label className="block text-xs text-slate-400 mb-1">Zusatzinfo (Optional)</label>
                           <input type="text" value={member.extraInfo || ''} onChange={(e) => { const newCab = [...officialsForm.cabinet]; newCab[idx].extraInfo = e.target.value; setOfficialsForm({...officialsForm, cabinet: newCab}); }} className="w-full border border-slate-300 dark:border-slate-600 p-1 rounded text-sm dark:bg-slate-700 dark:text-white" placeholder="z.B. Stellvertreter, Ehrenamtlich..." />
                        </div>
                        <div className="flex gap-2 mb-2">
                          <input type="text" value={member.imageUrl} onChange={(e) => { const newCab = [...officialsForm.cabinet]; newCab[idx].imageUrl = e.target.value; setOfficialsForm({...officialsForm, cabinet: newCab}); }} className="flex-grow text-xs text-slate-400 bg-slate-50 dark:bg-slate-900 p-1 border border-slate-300 dark:border-slate-600 rounded" placeholder="Bild URL" />
                          <label className="flex items-center justify-center px-2 py-1 bg-slate-200 dark:bg-slate-600 hover:bg-slate-300 rounded cursor-pointer text-slate-700 dark:text-slate-300 transition-colors">
                            <Upload size={14} />
                            <input type="file" className="hidden" accept="image/*" onChange={(e) => handleImageUpload(e, (url) => { const newCab = [...officialsForm.cabinet]; newCab[idx].imageUrl = url; setOfficialsForm({...officialsForm, cabinet: newCab}); })} />
                          </label>
                        </div>
                        <textarea value={member.description} onChange={(e) => { const newCab = [...officialsForm.cabinet]; newCab[idx].description = e.target.value; setOfficialsForm({...officialsForm, cabinet: newCab}); }} className="w-full border border-slate-300 dark:border-slate-600 p-2 text-sm rounded dark:bg-slate-700 dark:text-white" rows={2} placeholder="Beschreibung" />
                        
                        <button onClick={() => removeCabinetMember(member.id)} className="absolute top-2 right-2 text-red-400 hover:text-red-600 p-1"><Trash2 size={16} /></button>
                     </div>
                   ))}
              </div>
              <div className="flex justify-end pt-6">
                  <button onClick={handleOfficialsSave} disabled={isSaving} className="flex items-center gap-2 bg-blue-600 text-white px-6 py-2 rounded hover:bg-blue-700 shadow-sm disabled:opacity-50">
                    {isSaving ? <RefreshCw className="animate-spin" size={18} /> : <Save size={18} />} Speichern
                  </button>
              </div>
            </div>
          )}

          {/* --- CONGRESS TAB --- */}
          {activeTab === 'congress' && (
            <div className="bg-white dark:bg-slate-900 rounded-lg shadow p-6 animate-in fade-in duration-300 border dark:border-slate-800">
              <div className="flex justify-between items-center mb-6 border-b dark:border-slate-700 pb-4">
                <h2 className="text-xl font-bold text-slate-800 dark:text-white">Kongress Bearbeiten</h2>
                <button onClick={addCongressMember} className="flex items-center gap-2 bg-green-600 text-white px-4 py-2 rounded text-sm hover:bg-green-700 shadow-sm"><Plus size={16} /> Mitglied</button>
              </div>
              
              <div className="mb-6 grid gap-4">
                  <div>
                    <label className="block text-xs font-bold text-slate-500 dark:text-slate-400 uppercase mb-1">Seitentitel</label>
                    <input type="text" value={congressForm.pageTitle} onChange={(e) => setCongressForm({...congressForm, pageTitle: e.target.value})} className="w-full border border-slate-300 dark:border-slate-600 rounded p-2 dark:bg-slate-800 dark:text-white" />
                  </div>
                  <div>
                    <label className="block text-xs font-bold text-slate-500 dark:text-slate-400 uppercase mb-1">Untertitel</label>
                    <input type="text" value={congressForm.pageSubtitle} onChange={(e) => setCongressForm({...congressForm, pageSubtitle: e.target.value})} className="w-full border border-slate-300 dark:border-slate-600 rounded p-2 dark:bg-slate-800 dark:text-white" />
                  </div>
              </div>

              <div className="grid grid-cols-1 gap-4">
                {congressForm.members.map((member, idx) => (
                  <div key={member.id} className="flex flex-col sm:flex-row gap-4 border dark:border-slate-700 p-4 rounded-lg bg-slate-50 dark:bg-slate-800 relative">
                    <div className="w-24 h-24 flex-shrink-0 bg-gray-200 dark:bg-slate-700 rounded-md overflow-hidden">
                       <img src={member.imageUrl} alt="" className="w-full h-full object-cover" />
                    </div>
                    <div className="flex-grow grid grid-cols-1 sm:grid-cols-2 gap-3">
                       <input type="text" value={member.name} onChange={(e) => { const m = [...congressForm.members]; m[idx].name = e.target.value; setCongressForm({...congressForm, members: m}); }} className="border dark:border-slate-600 p-2 rounded font-bold dark:bg-slate-700 dark:text-white" placeholder="Name" />
                       <input type="text" value={member.party} onChange={(e) => { const m = [...congressForm.members]; m[idx].party = e.target.value; setCongressForm({...congressForm, members: m}); }} className="border dark:border-slate-600 p-2 rounded dark:bg-slate-700 dark:text-white" placeholder="Partei" />
                       <input type="text" value={member.district} onChange={(e) => { const m = [...congressForm.members]; m[idx].district = e.target.value; setCongressForm({...congressForm, members: m}); }} className="border dark:border-slate-600 p-2 rounded dark:bg-slate-700 dark:text-white" placeholder="Bezirk" />
                       <div className="flex gap-2 items-center">
                          <input type="text" value={member.imageUrl} onChange={(e) => { const m = [...congressForm.members]; m[idx].imageUrl = e.target.value; setCongressForm({...congressForm, members: m}); }} className="flex-grow border dark:border-slate-600 p-2 rounded font-mono text-xs dark:bg-slate-700 dark:text-white" placeholder="Bild URL" />
                          <label className="flex items-center justify-center px-2 py-2 bg-slate-200 dark:bg-slate-600 hover:bg-slate-300 rounded cursor-pointer text-slate-700 dark:text-slate-300 transition-colors">
                            <Upload size={14} />
                            <input type="file" className="hidden" accept="image/*" onChange={(e) => handleImageUpload(e, (url) => { const m = [...congressForm.members]; m[idx].imageUrl = url; setCongressForm({...congressForm, members: m}); })} />
                          </label>
                       </div>
                    </div>
                    <button onClick={() => removeCongressMember(member.id)} className="absolute top-2 right-2 text-red-400 hover:text-red-600 p-1"><Trash2 size={16} /></button>
                  </div>
                ))}
              </div>
              <div className="flex justify-end pt-6">
                  <button onClick={handleCongressSave} disabled={isSaving} className="flex items-center gap-2 bg-blue-600 text-white px-6 py-2 rounded hover:bg-blue-700 shadow-sm disabled:opacity-50">
                    {isSaving ? <RefreshCw className="animate-spin" size={18} /> : <Save size={18} />} Speichern
                  </button>
              </div>
            </div>
          )}

          {/* --- LAWS TAB --- */}
          {activeTab === 'laws' && (
            <div className="bg-white dark:bg-slate-900 rounded-lg shadow p-6 animate-in fade-in duration-300 border dark:border-slate-800">
              <div className="flex justify-between items-center mb-6 border-b dark:border-slate-700 pb-4">
                <h2 className="text-xl font-bold text-slate-800 dark:text-white">Gesetzbuch Bearbeiten</h2>
                <button onClick={addLaw} className="flex items-center gap-2 bg-green-600 text-white px-4 py-2 rounded text-sm hover:bg-green-700 shadow-sm"><Plus size={16} /> Gesetz</button>
              </div>
              
              <div className="mb-6 grid gap-4">
                  <div>
                    <label className="block text-xs font-bold text-slate-500 dark:text-slate-400 uppercase mb-1">Seitentitel</label>
                    <input type="text" value={lawsForm.pageTitle} onChange={(e) => setLawsForm({...lawsForm, pageTitle: e.target.value})} className="w-full border border-slate-300 dark:border-slate-600 rounded p-2 dark:bg-slate-800 dark:text-white" />
                  </div>
                  <div>
                    <label className="block text-xs font-bold text-slate-500 dark:text-slate-400 uppercase mb-1">Untertitel</label>
                    <input type="text" value={lawsForm.pageSubtitle} onChange={(e) => setLawsForm({...lawsForm, pageSubtitle: e.target.value})} className="w-full border border-slate-300 dark:border-slate-600 rounded p-2 dark:bg-slate-800 dark:text-white" />
                  </div>
              </div>

              <div className="space-y-4">
                {lawsForm.items.map((law, idx) => (
                  <div key={law.id} className="border dark:border-slate-700 p-4 rounded-lg bg-slate-50 dark:bg-slate-800 relative">
                     <div className="grid gap-3">
                       <div className="flex gap-3">
                         <input type="text" value={law.title} onChange={(e) => { const l = [...lawsForm.items]; l[idx].title = e.target.value; setLawsForm({...lawsForm, items: l}); }} className="flex-1 border border-slate-300 dark:border-slate-600 p-2 rounded font-bold dark:bg-slate-700 dark:text-white" placeholder="Titel" />
                         <input type="text" value={law.link} onChange={(e) => { const l = [...lawsForm.items]; l[idx].link = e.target.value; setLawsForm({...lawsForm, items: l}); }} className="w-1/3 border border-slate-300 dark:border-slate-600 p-2 rounded text-sm text-blue-600 dark:text-blue-400 dark:bg-slate-700" placeholder="Link URL" />
                       </div>
                       <textarea value={law.description} onChange={(e) => { const l = [...lawsForm.items]; l[idx].description = e.target.value; setLawsForm({...lawsForm, items: l}); }} className="w-full border border-slate-300 dark:border-slate-600 p-2 rounded dark:bg-slate-700 dark:text-white" rows={2} placeholder="Beschreibung" />
                     </div>
                     <button onClick={() => removeLaw(law.id)} className="absolute top-4 right-2 text-red-400 hover:text-red-600 p-1"><Trash2 size={16} /></button>
                  </div>
                ))}
              </div>
              <div className="flex justify-end pt-6">
                  <button onClick={handleLawsSave} disabled={isSaving} className="flex items-center gap-2 bg-blue-600 text-white px-6 py-2 rounded hover:bg-blue-700 shadow-sm disabled:opacity-50">
                    {isSaving ? <RefreshCw className="animate-spin" size={18} /> : <Save size={18} />} Speichern
                  </button>
              </div>
            </div>
          )}

          {/* --- BUSINESS TAB --- */}
          {activeTab === 'business' && (
            <div className="bg-white dark:bg-slate-900 rounded-lg shadow p-6 animate-in fade-in duration-300 border dark:border-slate-800">
              <div className="flex justify-between items-center mb-6 border-b dark:border-slate-700 pb-4">
                <h2 className="text-xl font-bold text-slate-800 dark:text-white">Gewerberegister Bearbeiten</h2>
                <button onClick={addBusiness} className="flex items-center gap-2 bg-green-600 text-white px-4 py-2 rounded text-sm hover:bg-green-700 shadow-sm"><Plus size={16} /> Eintrag</button>
              </div>
              
              <div className="mb-6 grid gap-4">
                  <div>
                    <label className="block text-xs font-bold text-slate-500 dark:text-slate-400 uppercase mb-1">Seitentitel</label>
                    <input type="text" value={businessForm.pageTitle} onChange={(e) => setBusinessForm({...businessForm, pageTitle: e.target.value})} className="w-full border border-slate-300 dark:border-slate-600 p-2 rounded dark:bg-slate-800 dark:text-white" />
                  </div>
                  <div>
                    <label className="block text-xs font-bold text-slate-500 dark:text-slate-400 uppercase mb-1">Untertitel</label>
                    <input type="text" value={businessForm.pageSubtitle} onChange={(e) => setBusinessForm({...businessForm, pageSubtitle: e.target.value})} className="w-full border border-slate-300 dark:border-slate-600 p-2 rounded dark:bg-slate-800 dark:text-white" />
                  </div>
              </div>

              <div className="space-y-4">
                {businessForm.registry.map((biz, idx) => (
                  <div key={biz.id} className="border dark:border-slate-700 p-4 rounded-lg bg-slate-50 dark:bg-slate-800 relative flex flex-col gap-3">
                     <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                       <div className="col-span-2 sm:col-span-1">
                          <label className="text-xs text-slate-400">Name</label>
                          <input type="text" value={biz.name} onChange={(e) => { const b = [...businessForm.registry]; b[idx].name = e.target.value; setBusinessForm({...businessForm, registry: b}); }} className="w-full border border-slate-300 dark:border-slate-600 p-1 rounded font-bold dark:bg-slate-700 dark:text-white" />
                       </div>
                       <div className="col-span-2 sm:col-span-1">
                          <label className="text-xs text-slate-400">Typ</label>
                          <input type="text" value={biz.type} onChange={(e) => { const b = [...businessForm.registry]; b[idx].type = e.target.value; setBusinessForm({...businessForm, registry: b}); }} className="w-full border border-slate-300 dark:border-slate-600 p-1 rounded dark:bg-slate-700 dark:text-white" />
                       </div>
                       <div className="col-span-2 sm:col-span-1">
                          <label className="text-xs text-slate-400">Inhaber</label>
                          <input type="text" value={biz.owner} onChange={(e) => { const b = [...businessForm.registry]; b[idx].owner = e.target.value; setBusinessForm({...businessForm, registry: b}); }} className="w-full border border-slate-300 dark:border-slate-600 p-1 rounded dark:bg-slate-700 dark:text-white" />
                       </div>
                       <div className="col-span-2 sm:col-span-1">
                          <label className="text-xs text-slate-400">Status</label>
                          <select value={biz.status} onChange={(e) => { const b = [...businessForm.registry]; b[idx].status = e.target.value; setBusinessForm({...businessForm, registry: b}); }} className="w-full border border-slate-300 dark:border-slate-600 p-1 rounded bg-white dark:bg-slate-700 dark:text-white">
                            <option value="Active">Active</option>
                            <option value="Suspended">Suspended</option>
                            <option value="Inactive">Inactive</option>
                          </select>
                       </div>
                     </div>
                     <div className="grid grid-cols-2 gap-3">
                        <div>
                           <label className="text-xs text-slate-400">Registriert am</label>
                           <input type="text" value={biz.registeredDate} onChange={(e) => { const b = [...businessForm.registry]; b[idx].registeredDate = e.target.value; setBusinessForm({...businessForm, registry: b}); }} className="w-full border border-slate-300 dark:border-slate-600 p-1 rounded dark:bg-slate-700 dark:text-white" />
                        </div>
                        <div>
                           <label className="text-xs text-slate-400">Läuft ab</label>
                           <input type="text" value={biz.expiryDate} onChange={(e) => { const b = [...businessForm.registry]; b[idx].expiryDate = e.target.value; setBusinessForm({...businessForm, registry: b}); }} className="w-full border border-slate-300 dark:border-slate-600 p-1 rounded dark:bg-slate-700 dark:text-white" />
                        </div>
                     </div>
                     <button onClick={() => removeBusiness(biz.id)} className="absolute top-2 right-2 text-red-400 hover:text-red-600 p-1"><Trash2 size={16} /></button>
                  </div>
                ))}
              </div>
              <div className="flex justify-end pt-6">
                  <button onClick={handleBusinessSave} disabled={isSaving} className="flex items-center gap-2 bg-blue-600 text-white px-6 py-2 rounded hover:bg-blue-700 shadow-sm disabled:opacity-50">
                    {isSaving ? <RefreshCw className="animate-spin" size={18} /> : <Save size={18} />} Speichern
                  </button>
              </div>
            </div>
          )}

        </div>
      </div>
    </div>
  );
};

export default Admin;
